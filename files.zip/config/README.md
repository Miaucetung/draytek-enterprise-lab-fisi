# Konfigurationen

Dieses Verzeichnis enthält Konfigurations-Backups, Vorlagen und Dokumentation. 

## Verzeichnis-Struktur
